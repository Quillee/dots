bellepintosgrande_icewm
 This is an IceWM theme. Move this directory to ~/.icewm/themes/ in order to use it.

colour_scheme_for_wine.reg
 This is a Wine registry key containing a colour scheme. Import it usine the Wine registry editor. 
 It should work without problems but I don't guarantee it. Back up your .wine folder before doing this. You can't hold me responsible for any harm that might result. 

